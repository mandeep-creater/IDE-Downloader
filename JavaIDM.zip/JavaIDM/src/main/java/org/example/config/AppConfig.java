package org.example.config;

public class AppConfig {

    public static  final String DOWNLOAD_PATH= "D:\\exe files\\JavaIDM\\IDM downloads";

    //other config information


}
